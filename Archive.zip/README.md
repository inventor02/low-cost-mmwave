# low-cost-mmwave

Collaborative Robot Perception with mm-Wave Radar, School of Electronics and Computer Science, University of Southampton
