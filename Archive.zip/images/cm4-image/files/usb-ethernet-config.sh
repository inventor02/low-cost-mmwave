#!/bin/bash

nmcli connection up usb0
