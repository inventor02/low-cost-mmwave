#!/bin/bash

# ensure the root user can log in (passwordless)
passwd -d root
