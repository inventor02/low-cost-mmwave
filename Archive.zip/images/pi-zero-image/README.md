# pi-zero-image

This is a Packer project to build reproducable images for the Pi Zero 2 W for the CoRoRa project.

Images are built on push by a GitLab CI runner at Astro House and published at http://svm-gjp1g21-gitlab-runner.ecs.soton.ac.uk/pi-zero-image (internal only).